[app]

title = واژگان قرآن نهم
package.name = quran9
package.domain = org.mjnalan
source.dir = .
source.include_exts = py,json,ttf,png,jpg,kv,atlas
version = 1.0.0
requirements = python3,kivy==2.3.1,arabic-reshaper,python-bidi
orientation = portrait
fullscreen = 0

android.api = 34
android.minapi = 23
android.ndk = 25b
android.archs = arm64-v8a,armeabi-v7a
android.accept_sdk_license = True
android.permissions =
android.allow_backup = True

[buildozer]
log_level = 2
warn_on_root = 1
