# واژگان قرآن نهم

برنامه آفلاین Kivy برای نمایش واژگان قرآن پایه نهم.

## ساخت APK
مخزن را در GitHub آپلود کنید. با هر push به شاخه `main`، گردش‌کار GitHub Actions اجرا می‌شود.
از زبانه Actions، اجرای `Build Quran9 APK` را باز کنید و فایل `Quran9-debug-apk` را از بخش Artifacts دریافت کنید.

## نیازمندی‌ها
Python 3، Kivy 2.3.1، arabic-reshaper و python-bidi.
