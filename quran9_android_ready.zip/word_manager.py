import json
from pathlib import Path


class WordManager:

    def __init__(self):
        self.file_path = (
            Path(__file__).resolve().parent
            / "data"
            / "vocabulary.json"
        )

        self.lessons = []
        self.load_data()

    def load_data(self):
        if not self.file_path.is_file():
            raise FileNotFoundError(
                f"File not found: {self.file_path}"
            )

        with open(
            self.file_path,
            mode="r",
            encoding="utf-8"
        ) as json_file:
            data = json.load(json_file)

        self.lessons = data.get("lessons", [])

    def get_all_words(self):
        words = []

        for lesson in self.lessons:
            for word in lesson.get("words", []):
                words.append({
                    "lesson_id": lesson["id"],
                    "lesson_title": lesson["title"],
                    "word": word["word"],
                    "meaning": word["meaning"]
                })

        return words

    def search(self, query):
        query = query.strip()

        if not query:
            return self.get_all_words()

        return [
            item for item in self.get_all_words()
            if query in item["word"]
            or query in item["meaning"]
        ]

    def get_lesson(self, lesson_id):
        for lesson in self.lessons:
            if lesson["id"] == lesson_id:
                return lesson

        return None